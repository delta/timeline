<?php
  $model  = array(
		'$model_name$' => 'timeline_users',
		"user_id" => 0,
		"user_name" => "test",
		"user_email" => "a@a.com"
	);
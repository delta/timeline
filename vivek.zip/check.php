<?php
		include 'tmp.php';

		$title = isset($_POST['title']) ? $_POST['title'] : null;
		$date  = isset($_POST['date']) ? $_POST['date'] : null;
		$desc  = isset($_POST['desc']) ? $_POST['desc'] : null;
		$cdate = 0;

    if($title == null or $date == null or $desc == null){
			echo "Please Fill in All Details";
    }else{
			$pdo = DB::connect();
			$sql = "INSERT INTO content_data (content_title, content_start_time, content_desc, content_end_time, content_revision_history, content_updated_by, content_modified_on, content_created_on) VALUES(:title, :date, :desc, :cet, :crh, :cub, :cmo, :cco)";
			$stm = $pdo->prepare($sql);
			$stm->execute(array(':title' => $title, ':date' => $date, ':desc' => $desc, ':cet' => $cdate, ':crh' => $cdate, ':cub' => $cdate, ':cmo' => $cdate, ':cco' => $cdate));
			echo $stm->rowCount();
		}
?>
